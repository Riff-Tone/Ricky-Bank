﻿<%@ WebService Language="C#" CodeBehind="TransactionService.asmx.cs" Class="Banking_member_page.TransactionService" %>
