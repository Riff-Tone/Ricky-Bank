﻿<%@ WebService Language="C#" CodeBehind="BankDetailsService.asmx.cs" Class="Banking_member_page.BankDetailsService" %>
